package compiler;

import word.Symbol;

import javax.swing.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class WordParser {

    /**
     * 保留字
     */
    private static final String[] WORDS = {
            "begin", "call", "const", "do", "end", "if",
            "odd", "procedure", "read", "then", "var", "while",
            "write"
    };

    /**
     * 单字符符号的单词类别对应表
     */
    private Map<Character, Symbol> singleSymbolMap = new HashMap<>();

    /**
     * 初始化工作
     */
    public WordParser() {
        initSingleSymbolMap();
    }

    /**
     * 设置单字符符号
     */
    private void initSingleSymbolMap() {
        singleSymbolMap.put('+', Symbol.plus);
        singleSymbolMap.put('-', Symbol.minus);
        singleSymbolMap.put('*', Symbol.times);
        singleSymbolMap.put('/', Symbol.slash);
        singleSymbolMap.put('(', Symbol.lparen);
        singleSymbolMap.put(')', Symbol.rparen);
        singleSymbolMap.put('=', Symbol.eql);
        singleSymbolMap.put(',', Symbol.comma);
        singleSymbolMap.put('.', Symbol.period);
        singleSymbolMap.put('#', Symbol.neq);
        singleSymbolMap.put(';', Symbol.semicolon);
    }

    /**
     * 单词的种类
     */
    public Symbol symbol;

    /**
     * 下一个单词的值（可能是标识符或保留字或符号）
     */
    public String id;

    /**
     * [无符号]整数数字的值
     */
    public int number;

    /**
     * 获取文件中下一个字符
     */
    private BufferedReader fileInputStream;

    char[] charBuffer = new char[128];
    int ptr = 0;
    int bufferLength = 0;

    private Character nextChar() {

        if (bufferLength == -1) {
            return null;
        }

        if (ptr >= bufferLength) {
            try {
                if (fileInputStream == null) {
                    String projectPath = this.getClass().getClassLoader().getResource("").getFile();
                    String fileName = "test.txt";
                    fileInputStream = new BufferedReader(new FileReader(projectPath + fileName));
                }
                bufferLength = fileInputStream.read(charBuffer);
                ptr = 0;
                if (bufferLength == -1) {
                    fileInputStream.close();
                    return null;
                }
            } catch (FileNotFoundException e) {
                throw new RuntimeException("ERROR : file-not-found ERROR.");
            } catch (IOException e) {
                throw new RuntimeException("ERROR : IO-Exception ERROR.");
            }
        }
        return charBuffer[ptr++];
    }

    /**
     * 词法分析的核心部分
     *
     * @return 是否分析到尽头
     */
    public boolean getSym() {
        Character c;
        while ((c = nextChar()) != null) {
            char chr = c;
            if (chr == ' ' || chr == 10 || chr == 13 || chr == 9) {
                continue;
            }
            boolean res = (isIndentOrSymbol(chr) || isSymbolOfUnsignedNumber(chr) ||
                    isSymbolOfBecomes(chr) || isSymbolOfSmallerThan(chr) || isSymbolOfGreaterThan(chr));
            if (!res) {
                setOtherSymbol(chr);
            }
            return true;
        }
        return false;
    }

    /**
     * 设置单字符符号的类别
     */
    private void setOtherSymbol(char chr) {
        this.symbol = singleSymbolMap.getOrDefault(chr, Symbol.nul);
        this.id = Character.toString(chr);
    }

    /**
     * 大于号或者大于等于号的判断
     */
    private boolean isSymbolOfGreaterThan(char chr) {
        if (chr != '>') {
            return false;
        }
        Character nextChar = nextChar();
        if (nextChar != null && nextChar == '=') {
            this.symbol = Symbol.geq;
            this.id = ">=";
        } else {
            this.symbol = Symbol.gtr;
            this.id = ">";
            if (ptr > 0) {
                ptr--;
            }
        }
        return true;
    }

    /**
     * 小于号或者小于等于号的判断。
     */
    private boolean isSymbolOfSmallerThan(char chr) {
        if (chr != '<') {
            return false;
        }
        Character nextChar = nextChar();
        if (nextChar != null && nextChar == '=') {
            this.symbol = Symbol.leq;
            this.id = "<=";
        } else {
            this.symbol = Symbol.lss;
            this.id = "<";
            if (ptr > 0) {
                ptr--;
            }
        }
        return true;
    }

    /**
     * 赋值号的判断
     */
    private boolean isSymbolOfBecomes(char chr) {
        Character nextChar = nextChar();
        if (chr == ':' && nextChar != null && nextChar == '=') {
            this.symbol = Symbol.becomes;
            this.id = ":=";
            return true;
        }
        ptr--;
        this.symbol = Symbol.nul;
        this.id = "nul";
        return false;
    }

    /**
     * 无符号整数的判断
     */
    private boolean isSymbolOfUnsignedNumber(char chr) {
        if (chr < '0' || chr > '9') {
            return false;
        }
        StringBuilder builder = new StringBuilder();
        builder.append(chr);
        int num = 0;
        num = num * 10 + chr - '0';
        Character tc;
        while ((tc = nextChar()) != null) {
            builder.append(tc);
            if (tc >= '0' && tc <= '9') {
                num = num * 10 + tc - '0';
            } else {
                if (tc >= 'a' && tc <= 'z' || tc >= 'A' && tc <= 'Z') {
                    System.out.println("Syntax Error:Word \"" + builder.toString() + "\" isn't Valid.");
                    this.symbol = Symbol.nul;
                    return true;
                }
                ptr--;
                break;
            }
        }
        this.symbol = Symbol.number;
        this.number = num;
        return true;

    }

    /**
     * 标识符或者保留字的判断
     */
    private boolean isIndentOrSymbol(char chr) {
        if (chr < 'a' || chr > 'z') {
            return false;
        }
        StringBuilder temp = new StringBuilder();
        temp.append(chr);
        Character tc;
        while ((tc = nextChar()) != null) {
            if (tc >= 'a' && tc <= 'z' || tc >= '0' && tc <= '9') {
                temp.append(tc);
            } else {
                ptr--;
                break;
            }
        }
        String word = temp.toString();
        symbol = isSymbolByBinarySearch(word) ? Symbol.valueOf(word + "sym") : Symbol.ident;
        id = word;

        return true;


    }

    /**
     * 对保留字进行二分搜索
     */
    private boolean isSymbolByBinarySearch(String temp) {
        int left = 0;
        int right = WORDS.length;
        while (left < right) {
            int mid = left + (right - left) / 2;
            String symbol = WORDS[mid];
            int res = temp.compareTo(symbol);
            if (res == 0) {
                return true;
            } else if (res > 0) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        return left < WORDS.length && temp.equals(WORDS[left]);
    }


}
