import compiler.WordParser;
import word.Symbol;

public class CompilerBoot {

    public static void main(String[] args) {
        WordParser parser = new WordParser();

        System.out.println("孔天欣 20188068 180235");
        while (parser.getSym()) {
            if (parser.symbol == Symbol.nul) {
                continue;
            }
            if (parser.symbol == Symbol.number) {
                System.out.println(parser.symbol.ordinal() + "," + parser.number);
            } else {
                System.out.println(parser.symbol.ordinal() + "," + parser.id);
            }
        }
    }
}
