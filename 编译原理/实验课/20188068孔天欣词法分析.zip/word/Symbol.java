package word;

public enum Symbol {

    // nul是不能识别的符号
    nul,
    // 标识符
    ident,
    // 无符号整数
    number,
    plus,
    // -
    minus,
    // *
    times,
    // 除
    slash,
    // =
    eql,
    // not equal
    neq,
    // lower than
    lss,
    // lower equal
    leq,
    // greater than
    gtr,
    // greater equal
    geq,
    // (
    lparen,
    // )
    rparen,
    // ,
    comma,
    // ;
    semicolon,
    // .
    period,
    // :=
    becomes,
    // 以下是保留字的单词类别
    oddsym,
    beginsym,
    endsym,
    ifsym,
    thensym,
    whilesym,
    dosym,
    callsym,
    constsym,
    varsym,
    // procsym
    proceduresym,
    readsym,
    writesym

}
